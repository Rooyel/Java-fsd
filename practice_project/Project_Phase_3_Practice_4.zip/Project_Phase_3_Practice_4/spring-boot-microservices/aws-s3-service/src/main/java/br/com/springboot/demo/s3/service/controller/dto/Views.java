package br.com.springboot.demo.s3.service.controller.dto;

public class Views {

	public interface onCreate {
	}
}
