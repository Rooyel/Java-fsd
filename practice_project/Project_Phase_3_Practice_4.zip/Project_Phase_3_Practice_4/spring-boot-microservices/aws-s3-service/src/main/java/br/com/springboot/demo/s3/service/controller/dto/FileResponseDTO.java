package br.com.springboot.demo.s3.service.controller.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@AllArgsConstructor
@Getter
@Setter
public class FileResponseDTO {

	private String fileUrl;

}
