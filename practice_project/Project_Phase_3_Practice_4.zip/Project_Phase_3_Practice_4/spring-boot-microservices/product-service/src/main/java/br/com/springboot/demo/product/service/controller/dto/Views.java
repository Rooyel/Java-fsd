package br.com.springboot.demo.product.service.controller.dto;

public class Views {

	public interface OnCreate {
	}

}
