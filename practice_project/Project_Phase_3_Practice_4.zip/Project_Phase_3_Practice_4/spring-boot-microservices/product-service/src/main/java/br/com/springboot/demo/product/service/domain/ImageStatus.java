package br.com.springboot.demo.product.service.domain;

public enum ImageStatus {

	UPLOADED, WAITING_UPLOAD, WAITING_DELETION;

}
