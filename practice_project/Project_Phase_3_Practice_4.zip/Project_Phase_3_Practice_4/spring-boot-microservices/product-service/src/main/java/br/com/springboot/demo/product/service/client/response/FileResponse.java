package br.com.springboot.demo.product.service.client.response;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@ToString
@Getter
@Setter
public class FileResponse {

	private String fileUrl;

}
