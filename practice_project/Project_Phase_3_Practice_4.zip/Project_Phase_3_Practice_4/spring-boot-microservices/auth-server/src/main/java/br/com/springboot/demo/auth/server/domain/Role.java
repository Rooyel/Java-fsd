package br.com.springboot.demo.auth.server.domain;

public enum Role {
	
	SUPER, ADMIN, USER;

}
