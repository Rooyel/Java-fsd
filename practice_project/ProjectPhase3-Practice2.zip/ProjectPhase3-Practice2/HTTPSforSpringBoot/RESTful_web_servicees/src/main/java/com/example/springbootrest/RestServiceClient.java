package com.example.springbootrest;

import org.springframework.web.client.RestTemplate;

public class RestServiceClient {
    private static final String REST_URL = "https://type.fit/api/quotes";

    private RestTemplate restTemplate;

    public RestServiceClient() {
        this.restTemplate = new RestTemplate();
    }

    public Quote[] getQuotes() {
        return restTemplate.getForObject(REST_URL, Quote[].class);
    }
}
