package com.example.springbootrest;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class QuoteController {
    @GetMapping("/random-quote")
    public Quote getRandomQuote() {
        // Here, you can create a new instance of Quote with a random quote text
        String randomQuoteText = "This is a random quote.";
        String author = "Anonymous";
        Quote quote = new Quote(randomQuoteText, author);
        return quote;
    }
}
