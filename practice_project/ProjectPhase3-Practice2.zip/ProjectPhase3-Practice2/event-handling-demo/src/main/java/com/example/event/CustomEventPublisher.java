package com.example.event;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Component;

@Component
public class CustomEventPublisher {

    @Autowired
    private ApplicationEventPublisher eventPublisher;

    public void publish(String message) {
        System.out.println("Publishing custom event");
        eventPublisher.publishEvent(new CustomEvent(this, message));
    }
}
