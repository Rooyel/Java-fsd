package com.example;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Main {
    public static void main(String[] args) {
        try (AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(SpringConfig.class)) {
            // Custom event publisher
            CustomEventPublisher customEventPublisher = context.getBean(CustomEventPublisher.class);
            customEventPublisher.publish("Custom event published");

            // No need to explicitly call for default event handling, Spring manages it.
        }
    }
}
