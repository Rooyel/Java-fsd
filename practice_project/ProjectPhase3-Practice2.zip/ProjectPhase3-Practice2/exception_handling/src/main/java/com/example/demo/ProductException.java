package com.example.demo;

import java.io.Serializable;

public class ProductException extends RuntimeException implements Serializable {

    private static final long serialVersionUID = 1L;

    public ProductException(String message) {
        super(message);
    }

    // Additional constructors or methods as needed
}
